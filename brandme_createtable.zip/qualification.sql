create table qualification (
	user_num int auto_increment,
	user_id varchar(10),
	edu boolean,
	work boolean,
	primary key(user_num)
);