create table userinfo (
	user_num int auto_increment,
	user_id varchar(10),
	user_pw varchar(20),
	user_name varchar(10),
	primary key(user_num)
);