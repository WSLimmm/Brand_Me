create table about (
	user_num int auto_increment,
	user_id varchar(10),
	about_img varchar(50),
	about_introduction varchar(20),
	experience int,
	project int,
	worked varchar(20),
	primary key(user_num)
);